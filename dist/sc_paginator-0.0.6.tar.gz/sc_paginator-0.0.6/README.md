# Python SC Paginator

A python lib with SC Series page logic calculation